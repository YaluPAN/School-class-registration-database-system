package Code.model.data;

public class Subject {
    private String subjectID;
    private String subjectName;
    private String subjectType;
    private String subjectCredit;
    private String subjectPre;
    private String subjectDept;

    public Subject(String subjectID, String subjectName, String subjectType, String subjectCredit, String subjectPre, String subjectDept) {
        this.subjectID = subjectID;
        this.subjectName = subjectName;
        this.subjectType = subjectType;
        this.subjectCredit = subjectCredit;
        this.subjectPre = subjectPre;
        this.subjectDept = subjectDept;
    }

    public String getSubjectID() {
        return subjectID;
    }

    public String getSubjectName() {
        return subjectName;
    }

    public String getSubjectType() {
        return subjectType;
    }

    public String getSubjectCredit() {
        return subjectCredit;
    }

    public String getSubjectPre() { return subjectPre; }

    public String getSubjectDept() {
        return subjectDept;
    }
}
