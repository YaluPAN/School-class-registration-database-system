
insert into Department (depid,depname)
values ('1','COMP');

insert into Department (depid,depname)
values ('2','AMA');

insert into Department (depid,depname)
values ('3','BME');

insert into Department
values ('4','MM');

insert into Student (StuID, StuName, StuDegree, Pass, DepID, Minor)
values ('1','a','1','1a','1',null);

insert into Student (StuID, StuName, StuDegree, Pass, DepID, Minor)
values ('2','b','1','2b','1','2');


insert into Student (StuID, StuName, StuDegree, Pass, DepID, Minor)
values ('3','c','2','3c','2',null);

insert into Student (StuID, StuName, StuDegree, Pass, DepID, Minor)
values ('4','d','2','4d','3','2');

insert into Student (StuID, StuName, StuDegree, Pass, DepID, Minor)
values ('5','e','2','5e','4','3');

insert into Student (StuID, StuName, StuDegree, Pass, DepID, Minor)
values ('6','f','2','6f','1',null);

insert into Student (StuID, StuName, StuDegree, Pass, DepID, Minor)
values ('7','g','2','7g','1','3');

insert into Student (StuID, StuName, StuDegree, Pass, DepID, Minor)
values ('8','h','2','8h','1','4');

insert into Subject (SubID, SubName, Pre, SubYr, SubType, SubCrd, DepID, Minor)
values ('COMP0001','C++','NO','1','Freshman Seminar','3','1','YES');

insert into Subject (SubID, SubName, Pre, SubYr, SubType, SubCrd, DepID, Minor)
values ('COMP0002','JAVA','COMP0001','2','Freshman Seminar','3','1','NO');

insert into Subject (SubID, SubName, Pre, SubYr, SubType, SubCrd, DepID, Minor)
values ('COMP0003','PHP','COMP0002','2','Freshman Seminar','3','1','NO');

insert into Subject (SubID, SubName, Pre, SubYr, SubType, SubCrd, DepID, Minor)
values ('AMA0001','COUNT','NO','1','CAR','3','2','NO');

insert into Subject (SubID, SubName, Pre, SubYr, SubType, SubCrd, DepID, Minor)
values ('BME0001','HEALTH','NO','1','HL','3','3','YES');

insert into Subject (SubID, SubName, Pre, SubYr, SubType, SubCrd, DepID, Minor)
values ('MM0001','MANAGEMENT','NO','2','ER/EW','3','4','YES');

insert into Professor (ProfID, ProfName, DepID)
values ('1','Pa','1');

insert into Professor (ProfID, ProfName, DepID)
values ('2','Pb','2');

insert into Professor (ProfID, ProfName, DepID)
values ('3','Pc','3');

insert into Professor (ProfID, ProfName, DepID)
values ('4','Pd','4');

insert into TeachAsit (TaID, TaName, DepID, ProfID)
values ('1','Ta','1','1');

insert into TeachAsit (TaID, TaName, DepID, ProfID)
values ('2','Tb','2','2');

insert into TeachAsit (TaID, TaName, DepID, ProfID)
values ('3','Tc','3','3');

insert into TeachAsit (TaID, TaName, DepID, ProfID)
values ('4','Td','4','4');


insert into ClsInfo (SubID, ProfID, TaID, ClsID, ClsCmp, ClsDay, ClsTime, ClsLoca, Vac, WList)
values ('COMP0001','1','1','1','lec','1','9:00,12:00', 'PQ000','50','0');

insert into ClsInfo (SubID, ProfID, TaID, ClsID, ClsCmp, ClsDay, ClsTime, ClsLoca, Vac, WList)
values ('COMP0001','2','2','2','lec','2','9:00,12:00', 'PQ001','50','0');

insert into ClsInfo (SubID, ProfID, TaID, ClsID, ClsCmp, ClsDay, ClsTime, ClsLoca, Vac, WList)
values ('COMP0002','3','3','1','lec','1','13:00,15:00', 'PQ003','50','0');

insert into ClsInfo (SubID, ProfID, TaID, ClsID, ClsCmp, ClsDay, ClsTime, ClsLoca, Vac, WList)
values ('COMP0002','3','3','2','lec','2','13:00,15:00', 'PQ003','50','0');

insert into ClsInfo (SubID, ProfID, TaID, ClsID, ClsCmp, ClsDay, ClsTime, ClsLoca, Vac, WList)
values ('AMA0001','3','3','1','lec','1','13:00,15:00', 'PQ003','50','0');

insert into ClsInfo (SubID, ProfID, TaID, ClsID, ClsCmp, ClsDay, ClsTime, ClsLoca, Vac, WList)
values ('BME0001','3','3','1','lec','2','13:00,15:00', 'PQ003','50','0');

insert into ClsInfo (SubID, ProfID, TaID, ClsID, ClsCmp, ClsDay, ClsTime, ClsLoca, Vac, WList)
values ('MM0001','4','4','1','lec','4','13:00,15:00', 'PQ005','50','0');

insert into TakenCls (StuID, SubID)
values ('1','COMP0001');


insert into TakenCls (StuID, SubID)
values ('7','COMP0001');

insert into cart (Stuid, subid,clsid)
values('1','COMP0001','1')