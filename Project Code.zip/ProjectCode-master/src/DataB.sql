CREATE TABLE Department(
    DepID varchar(10) NOT NULL PRIMARY KEY,
    DepName varchar(30) NOT NULL
    --DepLoc varchar(30) NOT NULL
);

CREATE TABLE Student(
    StuID varchar(10) NOT NULL PRIMARY KEY,
    StuName varchar(30) NOT NULL,
    StuDegree varchar(15) NOT NULL,
    Pass varchar(30) NOT NULL,
    DepID varchar(10) NOT NULL, --major
    Minor varchar(10), --minor
    FOREIGN KEY (DepID) REFERENCES Department(DepID),
    FOREIGN KEY (Minor) REFERENCES Department(DepID)
    --CGPA char(4)
);

CREATE TABLE Professor(
    ProfID varchar(10) NOT NULL PRIMARY KEY,
    ProfName varchar(30) NOT NULL,
    DepID varchar(10) NOT NULL,
    FOREIGN KEY (DepID) REFERENCES Department(DepID)
);

CREATE TABLE TeachAsit(
    TaID varchar(10) NOT NULL PRIMARY KEY,
    TaName varchar(30) NOT NULL,
    DepID varchar(10) NOT NULL,
    FOREIGN KEY (DepID) REFERENCES Department(DepID),
    ProfID varchar(10) NOT NULL,
    FOREIGN KEY (ProfID) REFERENCES Professor(ProfID)
);

CREATE TABLE Subject(
    SubID varchar(10) NOT NULL PRIMARY KEY,
    SubName varchar(30) NOT NULL,
    Pre varchar(10) NOT NULL,
    SubYr varchar(1) NOT NULL,
    SubType varchar(20) NOT NULL,
    SubCrd varchar(2) NOT NULL,
    DepID varchar(10) NOT NULL,
    Minor varchar(3) NOT NULL,
    FOREIGN KEY (DepID) REFERENCES Department(DepID)
    --SubTerm varchar(10) NOT NULL,
);

CREATE TABLE ClsInfo(
    SubID varchar(10) NOT NULL,
    ProfID varchar(10) NOT NULL,
    TaID varchar(10) NOT NULL,
    ClsID varchar(20) NOT NULL, -- 1,
    ClsCmp varchar(5) NOT NULL, -- lec/tut
    ClsDay varchar(10) NOT NULL,
    ClsTime varchar(20) NOT NULL,
    ClsLoca varchar(20) NOT NULL,
    Vac varchar(3) NOT NULL,
    WList varchar(2) NOT NULL,
    primary key(SubID,ClsID),
    FOREIGN KEY (ProfID) REFERENCES Professor(ProfID),
    FOREIGN KEY (TaID) REFERENCES TeachAsit(TaID),
    FOREIGN KEY (SubID) REFERENCES Subject(SubID)

);

CREATE TABLE Cart(
    StuID varchar(10) NOT NULL,
    SubID varchar(10) NOT NULL,
    ClsID varchar(10) NOT NULL,
    FOREIGN KEY (SubID,ClsID) REFERENCES ClsInfo(SubID,ClsID),
    FOREIGN KEY (StuID) REFERENCES Student(StuID)
);

CREATE TABLE TakenCls(
    StuID varchar(10) NOT NULL,
    SubID varchar(10) NOT NULL,
    FOREIGN KEY (StuID) REFERENCES Student(StuID),
    FOREIGN KEY (SubID) REFERENCES Subject(SubID)
);




