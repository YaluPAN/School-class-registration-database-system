package Code.model.data;
import java.sql.*;
import oracle.jdbc.pool.OracleDataSource;


/**
 *
 */
public class DBUtil {
    static String url="jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms";

    static String password = "";


    private static Connection conn;
    private static PreparedStatement ps;

    static String user = "";

    public void setPassword(String password) {
        DBUtil.password = password;
    }
    public void setUser(String user) {
        DBUtil.user = user;
    }

    private ResultSet rs;

    private static DBUtil db;
    public static DBUtil getDBUtil() {
        if (db == null) {
            db = new DBUtil();
        }
        return db;
    }


    public static Connection getConn(){
        System.out.println("Start connect");
        OracleDataSource ds;
        Connection conn = null;
        try {
            if (conn == null || conn.isClosed()) {

                ds = new OracleDataSource();
                ds.setURL(url);
                conn = ds.getConnection(user, password);
                conn = DriverManager.getConnection(url, user, password);
                System.out.println("Success");
            }
        }catch (SQLException e) {
            System.out.println("error");
            e.printStackTrace();
        }catch (Exception e) {
            System.out.println("error");
            e.printStackTrace();
        }
        return conn;
    }

    public void close() {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public ResultSet executeQuery(String sql, Object[] obj){
        if(getConn()==null) return null;

        try{
            ps = conn.prepareStatement(sql);
            for(int i=0;i<obj.length ;i++){
                ps.setObject(i+1,obj[i]);
            }
            rs=ps.executeQuery() ;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return rs;
    }

    public int executeUpdate(String sql, Object[] obj){
        int result=-1;
        if(getConn()==null){
            return result;
        }

        try{
            ps = conn.prepareStatement(sql);
            for(int i=0;i<obj.length ;i++){
                ps.setObject(i+1,obj[i]);
            }
            result=ps.executeUpdate();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return result;
    }

    public static void main(String[] args) {

        Statement st = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConn();
            st = conn.createStatement();
            String sql ="select * from EMP";

            rs = ps.executeQuery(sql);
            while (rs.next()) {
                int number = rs.getInt("EMPNO");
                String name = rs.getString("ENAME");
                System.out.println("id=" + number +"---" + "name=" + name + "---");
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

}
