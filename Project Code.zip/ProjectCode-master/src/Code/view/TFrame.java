package Code.view;
import Code.model.data.Account;
import Code.model.data.MyClass;
import Code.model.data.MyData;
import Code.model.data.Subject;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReference;


public class TFrame extends JFrame {

    TextField StuID;
    TextField passwordText;
    JLabel show;
    static MyData myData = new MyData() ;
    public static HashMap<String, String> storage = new HashMap<>();
    static String StudentID;
    JFrame frame = new JFrame();
    static JTable cartTable = new JTable(), infoTable = new JTable();
    JPanel mainPanel = new JPanel(), contentPanel = new JPanel(), buttonPanel = new JPanel();
    private static final String[] subjectHeader = {"Subject ID", "Subject Name", "Pre-requisite", "Subject Type", "Subject Credit"},
            classHeader = {"Class ID", "Teaching Staff", "Time", "Venue", "Vacancies", "Waiting List"},
            cartHeader = {"Subject ID", "Class ID", "Teaching Staff", "Time", "Venue"};



    public void initialization(){
       ArrayList<Account> accounts= myData.getAccountInfor();
       for(Account a:accounts){
           storage.put(a.getUsername(),a.getPassword());
       }

    }

    public void userLogin() {

        initialization() ;

        frame = new JFrame("Student Login");
        frame.setSize(500, 350);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        panel.setLayout(null);
        JLabel label = new JLabel("Student ID");
        label.setBounds(15, 25, 80, 30);
        panel.add(label);


        StuID = new TextField(15);
        StuID.setBounds(110, 25, 230, 30);
        panel.add(StuID);

        show = new JLabel("");
        show.setBounds(5, 5, 200, 20);
        panel.add(show);

        JLabel password = new JLabel("Password");
        password.setBounds(15, 100, 80, 30);
        panel.add(password);

        passwordText = new TextField(20);
        passwordText.setBounds(110, 100, 230, 30);
        panel.add(passwordText);

        JButton login = new JButton("login");
        login.setBounds(20, 200, 80, 25);
        panel.add(login);

        JButton reset = new JButton("reset");
        reset.setBounds(300, 200, 80, 25);
        panel.add(reset);

        frame.add(panel);
        frame.setVisible(true);

        reset.addActionListener(new Monitor());
        login.addActionListener(new Monitor());
    }

    public void userChoose() {

        frame = new JFrame("Choose options");
        frame.setSize(500, 350);
        JPanel panel = new JPanel();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel.setLayout(null);

        show = new JLabel("Your Student ID is: "+StudentID);///
        show.setBounds(10, 20, 400, 55);
        panel.add(show);

        JButton RegisterInfo = new JButton("View my cart");
        RegisterInfo.setBounds(20, 160, 155, 35);
        panel.add(RegisterInfo);
        RegisterInfo.addActionListener(new Monitor());

        JButton Back = new JButton("Quit");
        Back.setBounds(150, 200, 100, 35);
        panel.add(Back);
        Back.addActionListener(new Monitor());

        JButton StartRegister = new JButton("Start Register");
        StartRegister.setBounds(200, 160, 155, 35);
        panel.add(StartRegister);
        StartRegister.addActionListener(e -> {
            frame.dispose();
            this.studentView();
        });

        frame.add(panel);
        frame.setVisible(true);

    }

    public void studentViewInitialize() {
        /**
         Cart table
         */
        initTable(cartTable, getCartData(), cartHeader);
        cartTable.setGridColor(Color.blue);
        cartTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);


        /**
         Subject/Class table
         */
        initTable(infoTable, getSubjectData(), subjectHeader);
        infoTable.setGridColor(Color.red);
        infoTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);



    }
    public void ViewMyCart(){
        frame =new JFrame("View my Cart");
        frame.setSize(1000,618);
        JButton Back=new JButton("Back");
        Back.addActionListener(new Monitor());

        JPanel panel=new JPanel();

        initTable(cartTable, getCartData(), cartHeader);
        JScrollPane scrollPane = new JScrollPane(cartTable);
        scrollPane.setPreferredSize(new Dimension(500,309));
        panel.add(scrollPane);

        panel.add(Back);

        frame.add(panel);
        frame.setVisible(true);


    }

    public void studentView(){
        studentViewInitialize();
        frame = new JFrame("Choose options");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1070, 618);
        JLabel label = new JLabel();
        JTextField textField = new JTextField();
        textField.setPreferredSize(new Dimension(100,20) );
        AtomicReference<ArrayList<MyClass>> firstSearch = new AtomicReference<>(new ArrayList<>());

        mainPanel = new JPanel();
        frame.add(mainPanel);
        contentPanel = new JPanel();
        buttonPanel = new JPanel();
        buttonPanel.add(label, BorderLayout.BEFORE_LINE_BEGINS);

        JScrollPane scrollPane = new JScrollPane(cartTable);
        scrollPane.setPreferredSize(new Dimension(500,309));
        contentPanel.add(scrollPane);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        JScrollPane scrollPane1=new JScrollPane(infoTable);
        scrollPane1.setPreferredSize(new Dimension(500,309));
        contentPanel.add(scrollPane1);
        scrollPane1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        JLabel departmentLabel = new JLabel("Department");
        JComboBox<String> departmentBox = new JComboBox<>();
        departmentBox.addItem("--Please Select--");
        departmentBox.addItem("Computing");
        departmentBox.addItem("Electrical Engineering");
        departmentBox.addItem("Accounting and Financing");
        departmentBox.addItem("Applied Mathematics");
        departmentBox.addItem("Chinese Culture");
        departmentBox.addItem("Nursing");
        departmentBox.addItem("Building and Real Estate");


        JLabel subjectCategoryLabel = new JLabel("Subject Category");
        JComboBox<String> subjectCategoryBox = new JComboBox<>();
        subjectCategoryBox.addItem("--Please Select--");
        subjectCategoryBox.addItem("Common");
        subjectCategoryBox.addItem("Car");
        subjectCategoryBox.addItem("FreshmanSeminar");
        subjectCategoryBox.addItem("Service Learning");
        subjectCategoryBox.addItem("Healthy LifeStyle");
        subjectCategoryBox.addItem("ER/EW");
        JButton filterButton = new JButton("Filter");
        filterButton.addActionListener(e -> {
            String text2 = Objects.requireNonNull(subjectCategoryBox.getSelectedItem()).toString();
            String text1 = Objects.requireNonNull(departmentBox.getSelectedItem()).toString();

            if (text1.equals("--Please Select--")){
                text1 = null;
            }
            if (text2.equals("--Please Select--")){
                text2 = null;
            }
            String[][] filterInstance = getFilteredSubjectData(text1, text2);
            initTable(infoTable, filterInstance, subjectHeader);
        });


        JButton addButton = new JButton("Add Subject");
        buttonPanel.add(addButton);
        JButton Back = new JButton("Finish");
        buttonPanel.add(Back);
        Back.addActionListener(e -> {
            if (e.getActionCommand().equals("Finish")) {
                initTable(infoTable, getSubjectData(), subjectHeader);
                myData.writeBack(myData.getCart());
                frame.dispose();
                new TFrame().userChoose();
                filterButton.setVisible(true);
                departmentBox.setVisible(true);
                subjectCategoryBox.setVisible(true);
            } else if (e.getActionCommand().equals("Back")) {
                if (addButton.getText().equals("Add Class")) {
                    addButton.setText("Add Subject");
                    Back.setText("Finish");
                    initTable(infoTable, getSubjectData(), subjectHeader);
                    filterButton.setVisible(true);
                    departmentBox.setVisible(true);
                    subjectCategoryBox.setVisible(true);
                    return;
                }

                initTable(infoTable, getSubjectData(), subjectHeader);
                filterButton.setVisible(true);
                departmentBox.setVisible(true);
                subjectCategoryBox.setVisible(true);
            }

        });

        contentPanel.add(textField);

        addButton.addActionListener(e -> {
            if (e.getActionCommand().equals("Add Subject")) {
                String subID = textField.getText();
                if (subID.equals("")) {
                    JOptionPane.showMessageDialog(null, "Please input correct Subject ID!");
                    return;
                }

                for (MyClass cartClass : myData.getCart()) {
                    if (cartClass.getSubjectID().equals(subID)) {
                        JOptionPane.showMessageDialog(null, "Subject already exists!");
                        return;
                    }
                }

                boolean vacFlag = false, timeFlag = false;
                firstSearch.set(new ArrayList<>());
                // Classes with no vacancy or have time clash with current cart classes will be omitted
                for (MyClass myClass : myData.getClassesInfor()) {
                    if (myClass.getSubjectID().equals(subID)) {
                        vacFlag = checkVac(myClass);
                        timeFlag = checkTime(myClass);
                        System.out.println(vacFlag + " " + timeFlag);
                        if (vacFlag && timeFlag) firstSearch.get().add(myClass);
                    }
                }

                textField.setText(null);
                if (!vacFlag) {
                    JOptionPane.showMessageDialog(null, "No vacancy!");
                    if (!timeFlag) {
                        JOptionPane.showMessageDialog(null, "Time crash!");
                    }
                    return;
                }

                initTable(infoTable, getClassData(firstSearch.get()), classHeader);
                label.setText("Please enter a Class ID: ");
                addButton.setText("Add Class");
                Back.setText("Back");
                filterButton.setVisible(false);
                departmentBox.setVisible(false);
                subjectCategoryBox.setVisible(false);
            } else if (e.getActionCommand().equals("Add Class")) {
                String ClassID = textField.getText();
                if (ClassID.equals("")) {
                    JOptionPane.showMessageDialog(null, "Please input correct Subject ID!");
                    return;
                }

                boolean flag = false;
                for (MyClass search : firstSearch.get()) {
                    if (search.getClassID().equals(ClassID)) {
                        myData.getCart().add(search);
                        flag = true;
                    }
                }

                textField.setText(null);
                if (!flag) {
                    JOptionPane.showMessageDialog(null, "Class not available!");
                    return;
                }

                initTable(cartTable, getCartData(), cartHeader);
                JOptionPane.showMessageDialog(null, "Successful!");

            }
        });

        JButton dropButton = new JButton("Drop");
        dropButton.addActionListener(e -> {
            if (e.getActionCommand().equals("Drop Subject")) {
                String subID = textField.getText();
                if (subID.equals("")) {
                    JOptionPane.showMessageDialog(null, "Please input correct Subject ID!");
                    addButton.setText("Finish");
                    return;
                }

                boolean flag = false;
                for (MyClass myClass : myData.getClassesInfor()) {
                    if (myClass.getSubjectID().equals(subID)) {
                        myData.getCart().remove(myClass);
                        flag = true;
                    }
                }

                textField.setText(null);
                if (!flag) {
                    JOptionPane.showMessageDialog(null, "No such Subject!");
                    dropButton.setText("Finish");
                    return;
                }
                initTable(cartTable, getCartData(), cartHeader);
                JOptionPane.showMessageDialog(null, "Successful!");
                dropButton.setText("Finish");
            } else if (e.getActionCommand().equals("Finish")) {
                myData.writeBack(myData.getCart());
                dropButton.setText("Drop Subject");
            }
        });

        buttonPanel.add(filterButton);

        mainPanel.add(contentPanel);
        mainPanel.add(buttonPanel);
        mainPanel.add(departmentBox);
        mainPanel.add(departmentLabel);
        mainPanel.add(subjectCategoryBox);
        mainPanel.add(subjectCategoryLabel );

        frame.add(mainPanel);
        frame.setVisible(true);

    }

    private class Monitor implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("sign in")) {
                storage.put(StuID.getText(), passwordText.getText());
                System.out.println(storage.toString());

                show.setText("sign in successfully");


            } else if (e.getActionCommand().equals("reset")) {
                StuID.setText(null);
                passwordText.setText(null);
                show.setText(null);

            } else if (e.getActionCommand().equals("login")) {
                if (storage.containsKey(StuID.getText())) {
                    if (storage.get(StuID.getText()).equals(passwordText.getText())) {
                        show.setText("login in successfully");
                        StudentID=StuID .getText() ;
                        myData.startInitialize(StudentID);

                        frame.dispose();
                        //add another launcher
                        new TFrame().userChoose();
                        System.out.println(storage.toString());
                    } else {
                        show.setText("password is wrong!");
                    }
                } else {
                    show.setText("no such user");
                }
            } else if (e.getActionCommand().equals("View my cart")) {
                frame.dispose();
                new TFrame().ViewMyCart();
            } else if(e.getActionCommand().equals("Quit")){
                frame.dispose();
                new TFrame().userLogin();
            }else if(e.getActionCommand().equals("Back")){
                frame.dispose();
                new TFrame().userChoose();
            }
        }
    }



    public void initTable(JTable table, String[][] instances, String[] columnNames) {
        table.setModel(new DefaultTableModel(instances, columnNames));
    }

    public String[][] getSubjectData() {
        int numOfsubs = myData.getSubjectsInfor().size(), numOfcols = subjectHeader.length;
        if (numOfsubs == 0) return null;

        String[][] data = new String[numOfsubs][numOfcols];

        for (int i = 0; i < numOfsubs; i++) {
            Subject cur = myData.getSubjectsInfor().get(i);
            data[i][0] = cur.getSubjectID();
            data[i][1] = cur.getSubjectName();
            data[i][2] = cur.getSubjectPre();
            data[i][3] = cur.getSubjectType();
            data[i][4] = cur.getSubjectCredit();
        }

        return data;
    }

    public String[][] getFilteredSubjectData(String dept, String type) {
        int numOfsubs;

        // no filter
        if(dept == null && type == null) return getSubjectData();

        if(dept != null){
            myData.subjectFilter2(dept);
        }else if(type != null){
            myData.subjectFilter3(type);
        }

        if(dept != null && type != null) {
            myData.subjectFilter1(dept,type);
        }


        numOfsubs = myData.getSubjectFilter().size();
        if (numOfsubs == 0) return null;
        int numOfcols = subjectHeader.length;

        String[][] data = new String[numOfsubs][numOfcols];

        for (int i = 0; i < numOfsubs; i++) {
            Subject cur = myData.getSubjectFilter().get(i);
            data[i][0] = cur.getSubjectID();
            data[i][1] = cur.getSubjectName();
            data[i][2] = cur.getSubjectPre();
            data[i][3] = cur.getSubjectType();
            data[i][4] = cur.getSubjectCredit();
        }

        return data;
    }

    public String[][] getClassData(ArrayList<MyClass> classData) {
        int numOfcls = classData.size(), numOfcols = classHeader.length;
        if (numOfcls == 0) return null;

        String[][] data = new String[numOfcls][numOfcols];

        for (int i = 0; i < numOfcls; i++) {
            MyClass cur = classData.get(i);
            data[i][0] = cur.getClassID();
            data[i][1] = cur.getClassComponent().equals("lec") ? cur.getProName() : cur.getTaName();
            data[i][2] = cur.getDay() + ": " + cur.getStartTime() + "–" + cur.getEndTime();
            data[i][3] = cur.getClassLocation();
            data[i][4] = String.valueOf(cur.getVacancy());
            data[i][5] = String.valueOf(cur.getWaitingList()); // Waiting list
        }

        return data;
    }

    public String[][] getCartData() {
        int numOfcls = myData.getCart().size(), numOfcols = cartHeader.length;
        if (numOfcls == 0) return null;

        String[][] data = new String[numOfcls][numOfcols];

        for (int i = 0; i < numOfcls; i++) {
            MyClass cur = myData.getCart().get(i);
            data[i][0] = cur.getSubjectID();
            data[i][1] = cur.getClassID();
            data[i][2] = cur.getClassComponent().equals("lec") ? cur.getProName() : cur.getTaName();
            data[i][3] = cur.getDay() + ": " + cur.getStartTime() + "–" + cur.getEndTime();
            data[i][4] = cur.getClassLocation();
        }

        return data;
    }

    public boolean checkVac(MyClass cls) {
        return cls.getVacancy() > 0;
    }

    public boolean checkTime(MyClass cls) {
        for (MyClass myClass: myData.getCart()) {
            if (cls.getDay().equals(myClass.getDay())) {
                double clsStart = Double.parseDouble(cls.getStartTime().replaceAll(":","")),
                        clsEnd = Double.parseDouble(cls.getEndTime().replaceAll(":","")),
                        myClsStart = Double.parseDouble(myClass.getStartTime().replaceAll(":","")),
                        myClsEnd = Double.parseDouble(myClass.getEndTime().replaceAll(":",""));
                if ((clsEnd <= myClsStart && clsStart < myClsStart) || (clsStart >= myClsEnd && clsEnd > myClsEnd))
                    return true;
                else return false;
            }
        }
        return true;
    }
}


