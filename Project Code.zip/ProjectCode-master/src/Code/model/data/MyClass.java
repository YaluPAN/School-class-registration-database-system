package Code.model.data;

public class MyClass {
    private String subjectID, classID, startTime, endTime, taName, day,classLocation,proName,classComponent;
    private int vacancy, waitingList;
 //
    public MyClass(String subjectID, String classID, String startTime, String endTime, String taName, String day, String classLocation, String proName, String classComponent, int vacancy, int waitingList) {
        this.subjectID = subjectID;
        this.classID = classID;
        this.startTime = startTime;
        this.endTime = endTime;
        this.taName = taName;
        this.day = day;
        this.classLocation = classLocation;
        this.proName = proName;
        this.classComponent = classComponent;
        this.vacancy = vacancy;
        this.waitingList = waitingList;
    }

    public String getSubjectID() {
        return subjectID;
    }

    public String getClassID() {
        return classID;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getTaName() {
        return taName;
    }

    public String getDay() {
        return day;
    }

    public String getClassLocation() {
        return classLocation;
    }

    public String getProName() {
        return proName;
    }

    public String getClassComponent() {
        return classComponent;
    }

    public int getVacancy() {
        return vacancy;
    }

    public int getWaitingList() {
        return waitingList;
    }

}