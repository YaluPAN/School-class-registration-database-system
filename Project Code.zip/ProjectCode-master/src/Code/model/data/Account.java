package Code.model.data;

public class Account {
    private String StuID;
    private String Pass;

    public Account(String username, String password) {
        this.StuID = username;
        this.Pass = password;
    }

    public String getUsername() {
        return StuID;
    }

    public String getPassword() {
        return Pass;
    }
}
