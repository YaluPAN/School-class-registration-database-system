package Code.model.data;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class MyData {
    private final ArrayList<Subject> subjectsInfor;
    private ArrayList<Subject> subjectFilter;
    private final ArrayList<MyClass> classesInfor;
    private final ArrayList<MyClass> cart_list;
    private final ArrayList<Account> accountInfor;
    private String StuID;
    private Connection conn;
    private Statement st;

    public MyData(){
        subjectFilter = new ArrayList<>();
        subjectsInfor = new ArrayList<>();
        classesInfor = new ArrayList<>();
        cart_list = new ArrayList<>();
        accountInfor = new ArrayList<>();
        conn = DBUtil.getConn();
        try {
            st= conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
        }catch (Exception e) {
            System.out.println("statement create fail");
            e.printStackTrace();
        }
        initializeAccount();
    }

    public void startInitialize(String studentID) {
        this.StuID = studentID;
        System.out.printf("The student ID is: " +StuID);
        initializeSubject();
        initializeClass();;
        initializeCart();
    }

    public void subjectFilter1(String dept, String type){
        subjectFilter.clear();
        for(int i=subjectsInfor.size()-1;i>0;i--){
            if(subjectsInfor.get(i).getSubjectDept().equals(dept) && subjectsInfor.get(i).getSubjectType().equals(type)){
                subjectFilter.add(subjectsInfor.get(i));
            }
        }
    }

    public void subjectFilter2(String dept){
        subjectFilter.clear();
        for(int i=subjectsInfor.size()-1;i>0;i--){
            if(subjectsInfor.get(i).getSubjectDept().equals(dept)){
                subjectFilter.add(subjectsInfor.get(i));
            }
        }

    }
    public void subjectFilter3(String type){
        subjectFilter.clear();
        for(int i=subjectsInfor.size()-1;i>0;i--){
            if(subjectsInfor.get(i).getSubjectType().equals(type)){
                subjectFilter.add(subjectsInfor.get(i));
            }
        }

    }

    private void initializeAccount(){
        try
        {
            String query = "SELECT StuID, Pass FROM Student";
            ResultSet rs = st.executeQuery(query);
            while (rs.next())
            {
                String StuID = rs.getString("STUID");
                String StuName = rs.getString("PASS");
                Account account = new Account(StuID,StuName);
                accountInfor.add(account);

            }
            for(Account a : accountInfor) {
                System.out.println(a.getUsername() + " " + a.getPassword());
            }
        }
        catch (Exception e)
        {
            System.err.println("Account initialize fail! ");
            System.err.println(e.getMessage());
        }
    }




    // get the subject that the student can choose
    private void initializeSubject(){
        try {
            System.out.println("Start initialize Subject...");
            ArrayList<String> takenClass = new ArrayList<>();
            //the subject that do not consider pre
            String getSubject1 = "select DISTINCT subject.subid, subject.subname, department.depname, subject.subtype, subject.subcrd, subject.pre " +
                    "from student , subject, department " +
                    "where  student.stuid = '" + StuID + "' and subject.depid = department.depid and (subject.subtype != 'Common' or ( (subject.depid = department.depid  or (student.minor = subject.depid and subject.minor = 'YES') ) and (subject.subyr = student.stuyr)))";
            //get the take table
            String getTakeTable = "select subid from takencls where takencls.stuid = '" + StuID+"'";
            ResultSet result2 = st.executeQuery(getTakeTable);
            //store the taken table
            while (result2.next()) {
                String subID = result2.getString("SUBID");
                takenClass.add(subID);
            }
            ResultSet result1 = st.executeQuery(getSubject1);
            //judge the situation of pre request
            while (result1.next()){
                boolean flag = true;
                String subID = result1.getString("SUBID");
                String subName = result1.getString("SUBNAME");
                String subType = result1.getString("SUBTYPE");
                String subCrd = result1.getString("SUBCRD");
                String pre = result1.getString("PRE");
                String depName = result1.getString("DEPNAME");
                pre.trim();
                if(!pre.equals("NO")){
                    flag = false;
                    for(int i = 0; i < takenClass.size(); i++){
                        if(takenClass.get(i).equals(pre)){
                            flag = true;
                            break;
                        }
                    }
                }
                if(flag){
                    Subject newSubject = new Subject(subID,subName,subType,subCrd,pre,depName);
                    subjectsInfor.add(newSubject);
                }
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Subject initialized successfully");
    }



    private void initializeCart(){
        try
        {
            System.out.println("Start initialize cart");
            String query = "select a.subid, a.clsid, b.profname, c.taname,a.clscmp,a.clsday,a.clstime,a.clsloca,a.vac,a.wlist from clsinfo a, professor b, teachasit c, cart d where a.taid = c.taid and a.profid = b.profid and d.subid = a.subid and d.clsid = a.clsid and d.stuid = '" + StuID + "'";

            ResultSet rs = st.executeQuery(query);
            while (rs.next())
            {
                String subID = rs.getString("SUBID");
                String clsID = rs.getString("CLSID");
                String profName = rs.getString("PROFNAME");
                String taName = rs.getString("TANAME");
                String clsCmp = rs.getString("CLSCMP");
                String clsDay = rs.getString("CLSDAY");
                String clsTime = rs.getString("CLSTIME");
                String clsLoca = rs.getString("CLSLOCA");
                String vac = rs.getString("VAC");
                String wlist = rs.getString("WLIST");
                String[] time = clsTime.split(","); // divide the time by ','
                String startTime = time[0];
                String endTIme = time[1];
                MyClass newCart = new MyClass(subID,clsID,startTime,endTIme,taName,clsDay,clsLoca,profName,clsCmp,Integer.valueOf(vac),Integer.valueOf(wlist));
                cart_list.add(newCart);
            }
        }
        catch (Exception e)
        {
            System.err.println("Cart initialize fail! ");
            System.err.println(e.getMessage());
        }
        System.out.println("Cart initialized successfully");
    }

    private void initializeClass(){
        try {
            System.out.println("Start initialize class");
            for(int i = 0; i < subjectsInfor.size(); i++){
                String subjectID = subjectsInfor.get(i).getSubjectID();
                // get table according to subjectid;
                String getClass = "select a.subid, a.clsid, b.profname, c.taname,a.clscmp,a.clsday,a.clstime,a.clsloca,a.vac,a.wlist from Clsinfo a, professor b, teachasit c where a.taid = c.taid and a.profid = b.profid and subid = '" + subjectID + "'";
                ResultSet allClass = st.executeQuery(getClass);
                while (allClass.next()) {
                    String subID = allClass.getString("SUBID");
                    String clsID = allClass.getString("CLSID");
                    String profName = allClass.getString("PROFNAME");
                    String taName = allClass.getString("TANAME");
                    String clsCmp = allClass.getString("CLSCMP");
                    String clsDay = allClass.getString("CLSDAY");
                    String clsTime = allClass.getString("CLSTIME");
                    String clsLoca = allClass.getString("CLSLOCA");
                    String vac = allClass.getString("VAC");
                    String wlist = allClass.getString("WLIST");
                    String[] time = clsTime.split(","); // divide the time by ','
                    String startTime = time[0];
                    String endTIme = time[1];
                    MyClass newClass = new MyClass(subID,clsID,startTime,endTIme,taName,clsDay,clsLoca,profName,clsCmp,Integer.valueOf(vac),Integer.valueOf(wlist));
                    classesInfor.add(newClass);
                }
            }
        }catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("Class initialize successfully");
    }

    public void writeBack(ArrayList<MyClass> newCart){
        try {
            System.out.println("Start write back");
            ArrayList<MyClass> oldCart = new ArrayList<>();
            ArrayList<MyClass> newDelete = new ArrayList<>();
            ArrayList<MyClass> newAdd = new ArrayList<>();
            // get old cart
            String getOldCart =  "select a.subid, a.clsid, b.profname, c.taname,a.clscmp,a.clsday,a.clstime,a.clsloca,a.vac,a.wlist from clsinfo a, professor b, teachasit c, cart d where a.taid = c.taid and a.profid = b.profid and d.subid = a.subid and d.clsid = a.clsid and d.stuid = '" + StuID + "'";
            ResultSet old = st.executeQuery(getOldCart);
            while (old.next())
            {
                String subID = old.getString("SUBID");
                String clsID = old.getString("CLSID");
                String profName = old.getString("PROFNAME");
                String taName = old.getString("TANAME");
                String clsCmp = old.getString("CLSCMP");
                String clsDay = old.getString("CLSDAY");
                String clsTime = old.getString("CLSTIME");
                String clsLoca = old.getString("CLSLOCA");
                String vac = old.getString("VAC");
                String wlist = old.getString("WLIST");
                String[] time = clsTime.split(","); // divide the time by ','
                String startTime = time[0];
                String endTIme = time[1];
                MyClass cart = new MyClass(subID,clsID,startTime,endTIme,taName,clsDay,clsLoca,profName,clsCmp,Integer.valueOf(vac),Integer.valueOf(wlist));
                oldCart.add(cart);
            }
            for(MyClass a : oldCart) {
                boolean flag = false;
                for(MyClass b: newCart) {
                    if(a.getSubjectID().equals(b.getSubjectID()) && a.getClassID().equals(b.getClassID())) {
                        flag = true;
                        break;
                    }
                }
                if (!flag){
                    newDelete.add(a);
                }
            }
            for(MyClass a : newCart) {
                boolean flag = false;
                for(MyClass b: oldCart) {
                    if(a.getSubjectID().equals(b.getSubjectID()) && a.getClassID().equals(b.getClassID())) {
                        flag = true;
                        break;
                    }
                }
                if (!flag){
                    newAdd.add(a);
                }
            }
            

            //update cart
            updateCart(newDelete,newAdd);
            //update vac and waiting list of class
            updateClass(newDelete,newAdd);
            System.out.println("Update finish");

        }catch (Exception e) {
            System.out.println("Write back fail");
            e.printStackTrace();
        }

    }

    private void updateCart(ArrayList<MyClass> needDelete, ArrayList<MyClass> needAdd){
        try {
            // delete the remove
            for(MyClass delete : needDelete){
                String update = "delete from cart where stuid = '"+ StuID+"' and subid = '" + delete.getSubjectID() + "' and clsid = '" + delete.getClassID() + "'";
                st.executeUpdate(update);
            }
            // add the new
            for(MyClass add : needAdd) {
                String update = "insert into cart (Stuid, subid,clsid) values('" + StuID + "' , '" + add.getSubjectID() + "' , '" +  add.getClassID() + "')";
                st.executeUpdate(update);
            }
        }catch (Exception e) {
            System.out.println("Update cart fail");
            e.printStackTrace();
        }
    }

    private void updateClass(ArrayList<MyClass> needDelete, ArrayList<MyClass> needAdd){
        try {
            //add the vac
            for(MyClass delete : needDelete){
                String query = "select vac, wlist from clsinfo where clsid = '" + delete.getClassID() + "' and  subid = '" + delete.getSubjectID() + "' ";
                ResultSet result = st.executeQuery(query);
                while (result.next()) {
                    String vac = result.getString("VAC");
                    String waitingList = result.getString("WLIST");
                    int vacNumber = Integer.valueOf(vac);
                    int waitingNumber = Integer.valueOf(waitingList);
                    waitingNumber--;
                    if(waitingNumber == -1) {
                        vacNumber++;
                        waitingNumber++;
                    }
                    vac = String.valueOf(vacNumber);
                    waitingList = String.valueOf(waitingNumber);
                    String update = "update clsinfo set vac = '" + vac + "' , wlist = '" +  waitingList + "'  where clsid = '" + delete.getClassID() + "' and  subid = '" + delete.getSubjectID() + "' ";
                    st.executeUpdate(update);
                }
            }
            //delete vac
            for(MyClass add : needAdd) {
                String query = "select vac, wlist from clsinfo where clsid = '" + add.getClassID() + "' and  subid = '" + add.getSubjectID() + "' ";
                ResultSet result = st.executeQuery(query);
                while (result.next()) {
                    String vac = result.getString("VAC");
                    String waitingList = result.getString("WLIST");
                    int vacNumber = Integer.valueOf(vac);
                    int waitingNumber = Integer.valueOf(waitingList);
                    vacNumber--;
                    if(vacNumber == -1) {
                        vacNumber++;
                        waitingNumber++;
                    }
                    vac = String.valueOf(vacNumber);
                    waitingList = String.valueOf(waitingNumber);
                    String update = "update clsinfo set vac = '" + vac + "' , wlist = '" +  waitingList + "'  where clsid = '" + add.getClassID() + "' and  subid = '" + add.getSubjectID() + "' ";
                    st.executeUpdate(update);
                }
            }
        }catch (Exception e) {
            System.out.println("Update class fail");
            e.printStackTrace();
        }
    }

    public ArrayList<Subject> getSubjectsInfor() {
        return subjectsInfor;
    }

    public ArrayList<Subject> getSubjectFilter() { return subjectFilter; }

    public ArrayList<MyClass> getClassesInfor() {
        return classesInfor;
    }

    public ArrayList<MyClass> getCart() {
        return cart_list;
    }


    public ArrayList<Account> getAccountInfor() {
        return accountInfor;
    }

    public String getStudentID() { return StuID; }
}
