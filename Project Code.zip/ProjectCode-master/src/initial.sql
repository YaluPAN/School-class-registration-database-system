--account
SELECT StuID, Pass
FROM Student

--
SELECT SubID, ClsID
FROM Cart
WHERE StuID =